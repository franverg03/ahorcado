window.onload = function () {
    // Array de letras del juego
    var letras = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    let divLetras = document.getElementById("letras"); // Contenedor donde se mostrarán los botones de letras

    var intentos = 6; // Número inicial de intentos permitidos
    var palabraAleatoria, letrasAcertadas;
    var palabras = ["Gato", "Perro", "Elefante", "Mariposa", "Estrella", "Cielo", "Mesa", "Silla", "Ventana", "Puerta", "Libro", "Casa",
        "Fruta", "Chocolate", "Reloj", "Sopa", "Ciudad", "Viaje", "Carro", "Juguete", "Ordenador", "Periquito", "Conejo",
        "Cancion", "Luna", "Nube", "Fuego", "Agua", "Tierra", "Viento", "Amigo", "Familia", "Fiesta", "Juego", "Cerveza",
        "Dulce", "Nieve", "Playa", "Primavera", "Invierno", "Verano"];

    var contenedorMenu = document.getElementById("contenedorMenu");
    var btnJugar = document.getElementById("jugar");
    var btnInicio = document.getElementById("inicio");
    var resultado = document.getElementById("resultado");
    var btnReglas = document.getElementById("VerReglas");
    var reglas = document.getElementById("reglas");

    btnJugar.addEventListener("click", jugar);
    btnReglas.addEventListener("click", mostrarReglas);

    // Función que inicia el juego
    function jugar() {
        // Oculta ciertos elementos del menú y ajusta el diseño
        contenedorMenu.style.paddingTop = "50px";
        btnJugar.style.display = "none";
        btnReglas.style.display = "none";
        let juego = document.getElementById("juego");

        // Muestra el área de juego y reinicia los intentos y el resultado
        juego.classList.remove("d-none");
        var resultado = document.getElementById("resultado");
        resultado.style.display = "none";
        resultado.innerHTML = "";
        intentos = 6;

        // Selecciona aleatoriamente una palabra de la lista y la convierte a mayúsculas
        palabraAleatoria = palabras[Math.floor(Math.random() * palabras.length)].toUpperCase();
        console.log(palabraAleatoria);


        letrasAcertadas = Array(palabraAleatoria.length).fill("_");// Inicializo el array de letras acertadas con guiones bajos
        document.getElementById("palabraOculta").textContent = letrasAcertadas.join(" "); // Muestro los guiones bajos como la palabra oculta
        document.getElementById("intentos").textContent = "Intentos restantes: " + intentos; // Muestra el número de intentos restantes

        // Restablece la imagen del muñeco colgado
        document.getElementById("imagenMunyeco").src = "img/ahorcado_6.png";

        // Habilita todos los botones de letras para cuando se vuelve a jugar
        let botones = document.getElementById("letras").getElementsByTagName("button");
        for (let i = 0; i < botones.length; i++) {
            botones[i].disabled = false;
        }

        adivinarLetra();
    }

    // Función para mostrar las reglas del juego
    function mostrarReglas() {
        btnJugar.style.display = "none";
        btnReglas.style.display = "none";
        reglas.classList.remove("d-none");
    }

    // Función para generar los botones de letras si no existen y asignarles eventos
    function adivinarLetra() {
        if (divLetras.children.length === 0) {
            for (let i = 0; i < letras.length; i++) {
                // Crea un botón por cada letra del array de letras
                var boton = document.createElement("button");
                boton.id = "btn-" + letras[i];
                boton.textContent = letras[i].toUpperCase();
                boton.classList = "btn btn-outline-light btn-lg ";
                boton.disabled = false;
                divLetras.appendChild(boton);

                // Asigna el evento para comprobar la letra cuando se hace clic en el botón
                boton.addEventListener("click", comprobarLetra);
            }
            // Asigna un evento para detectar cuando se presionan teclas en el teclado
            document.addEventListener("keyup", comprobarLetraTec);
        }
    }

    // Función que comprueba si la letra seleccionada es parte de la palabra
    function comprobarLetra() {
        this.disabled = true; // Desactiva el botón de la letra seleccionada

        let acertado = false;

        // Recorre la palabra aleatoria para ver si la letra está
        for (let i = 0; i < palabraAleatoria.length; i++) {
            if (palabraAleatoria[i] === this.textContent) {
                letrasAcertadas[i] = this.textContent; // Reemplaza el guión bajo con la letra acertada
                acertado = true;
            }
        }

        // Si la letra no está en la palabra, reduce los intentos y cambia la imagen del muñeco
        if (!acertado) {
            intentos--;
            let imagen = document.getElementById("imagenMunyeco");
            imagen.src = "img/ahorcado_" + intentos + ".png";
        }

        // Actualiza la palabra oculta con las letras acertadas
        document.getElementById("palabraOculta").textContent = letrasAcertadas.join(" ");
        document.getElementById("intentos").textContent = "Intentos restantes: " + intentos;

        // Comprueba si se ha ganado o perdido
        comprobarVictoria();
    }

    // Función para detectar las letras seleccionadas a través del teclado
    function comprobarLetraTec(evt) {
        var tecla = evt.key.toLowerCase(); // Convierte la tecla pulsada a minúscula

        // Comprueba si la tecla pulsada está en el array de letras
        if (letras.includes(tecla)) {
            for (let i = 0; i < letras.length; i++) {
                let boton = document.getElementById("btn-" + letras[i]);

                // Simula el clic en el botón correspondiente si la letra coincide y el botón no está deshabilitado
                if (boton.textContent.toLowerCase() === tecla && !boton.disabled) {
                    boton.click();
                }
            }
        }
    }

    // Función que comprueba si el jugador ha ganado o perdido
    function comprobarVictoria() {
        if (intentos === 0) {
            resultado.style.display = "block";
            let p = document.createElement("p");
            p.style = "text-align:center; font-size: 50px";
            p.textContent = "¡Has perdido! La palabra era " + palabraAleatoria;
            resultado.appendChild(p);
            btnJugar.style.display = "block";
            btnJugar.textContent = "Volver a jugar";
        }


        if (!letrasAcertadas.includes("_")) {
            resultado.style.display = "block";
            let p = document.createElement("p");
            p.style = "text-align:center; font-size: 50px";
            p.textContent = "¡Has ganado!";
            resultado.appendChild(p);
            btnJugar.style.display = "block";
            btnJugar.textContent = "Volver a jugar";
        }
    }
}
